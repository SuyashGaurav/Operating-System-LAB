#!/bin/sh
./syscall.sh &
./fstime.sh &
./arithoh.sh &
./fstime.sh &
./syscall.sh &
wait